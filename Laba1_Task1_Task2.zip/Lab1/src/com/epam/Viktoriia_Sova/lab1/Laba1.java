package com.epam.Viktoriia_Sova.lab1;

import java.util.Arrays;

public class Laba1 {

	/**
	 * @param args
	 */
	/*
	 * public static void main(String[] args) { // TODO Auto-generated method
	 * stub int[] arr = { 5, 4, 3, 2, 1, 0 }; int[] a = { 10, 11, 12, 13, 14, 5,
	 * 6, 7, 8, 9 }; int[][] matrix1 = { { 1, 2 }, { 7, 8 }, { 3, 4 } }; int[][]
	 * matrix2 = { { 3, 4, 5, 6 }, { 9, 0, 1, 2 } }; /* invert(arr);
	 * System.out.println(Arrays.toString(arr)); int[] s = merge(a, arr);
	 * sort(arr); System.out.println(Arrays.toString(arr)); sortMin(arr);
	 * System.out.println(Arrays.toString(arr)); insertionSorter(arr);
	 */
	// matrix(matrix1, matrix2);
	/*
	 * sort(arr); System.out.println(Arrays.toString(arr)); }
	 */
	public static void invert(int[] arr1) {
		int[] arr = arr1.clone();
		for (int k = arr.length / 2; k >= 0 / 2; k--) {
			int tmp = arr[k];
			arr[k] = arr[arr.length - k - 1];
			arr[arr.length - k - 1] = tmp;
		}
		System.out.println(Arrays.toString(arr));
	}

	public static void merge(int[] fst, int[] snd) {
		int[] result = new int[fst.length + snd.length];
		int fstIndex = 0;
		int sndIndex = 0;
		while (fstIndex + sndIndex != result.length) {
			if (fst[fstIndex] < snd[sndIndex]) {
				result[fstIndex + sndIndex] = fst[fstIndex++];
				if (fstIndex == fst.length) {
					System.arraycopy(snd, sndIndex, result,
							fstIndex + sndIndex, snd.length - sndIndex);
					break;
				}
			} else {
				result[fstIndex + sndIndex] = snd[sndIndex++];
				if (sndIndex == snd.length) {
					System.arraycopy(fst, fstIndex, result,
							fstIndex + sndIndex, fst.length - fstIndex);
					break;
				}
			}
		}
		System.out.println(Arrays.toString(result));
	}

	public static void sort(int[] arr1) {
		int[] arr = arr1.clone();
		for (int barrier = 0; barrier < arr.length; barrier++) {
			for (int index = barrier + 1; index < arr.length; index++) {
				if (arr[barrier] > arr[index]) {
					int tmp = arr[index];
					arr[index] = arr[barrier];
					arr[barrier] = tmp;
					System.out.print(arr[barrier] + "-" + arr[index] + " ");
				}
			}
			System.out.println();
		}
		System.out.println(Arrays.toString(arr));
	}

	public static void sortMin(int[] arr1) {
		int[] arr = arr1.clone();
		for (int k = 1; k < arr.length; k++) {
			int newElement = arr[k];
			int location = k - 1;
			while (location >= 0 && arr[location] > newElement) {
				arr[location + 1] = arr[location];
				location--;
			}
			arr[location + 1] = newElement;
		}
		System.out.println(Arrays.toString(arr));
	}

	public static void insertionSorter(int[] arr1) {
		int[] arr = arr1.clone();
		for (int k = 1; k < arr.length; k++) {
			int foundIndex = Arrays.binarySearch(arr, arr[k]);
			if (foundIndex < 0) {
				int insertIndex = -foundIndex - 1;
				int[] result = Arrays.copyOf(arr, arr.length + 1);
				for (int i = result.length - 1; i > insertIndex; i--)
					result[i] = result[i - 1];
				result[insertIndex] = arr[k];
				int newElement = arr[k];
				int location = k - 1;
				while (location >= 0 && arr[location] > newElement) {
					arr[location + 1] = arr[location];
					location--;
				}
				arr[location + 1] = newElement;
			}
		}
		System.out.println(Arrays.toString(arr));
	}

	public static void matrix(int[][] arr1, int[][] arr2) {
		int[][] c = new int[arr1.length][arr2[0].length];
		for (int i = 0; i < arr1.length; i++) {
			for (int j = 0; j < arr2[0].length; j++)
				for (int k = 0; k < arr2.length; k++) {
					c[i][j] += arr1[i][k] * arr2[k][j];
				}
		}
		System.out.println(Arrays.deepToString(c));
	}
}
