package com.epam.Viktoriia_Sova.lab1;

public class ValidateValue {
	public static String validate(String s) {
		s = s.trim();
		String numbers = "";
		for (int i = 0; i < s.length(); i++) {
			switch (s.charAt(i)) {
			case '0':
			case '1':
			case '2':
			case '3':
			case '4':
			case '5':
			case '6':
			case '7':
			case '8':
			case '9':
			case ' ': {
				numbers += s.charAt(i);
				break;
			}
			default: {
				break;
			}
			}
		}
		return numbers;
	}

	public static boolean nullValue(String s) {
		s = s.trim();
		boolean flag = true;
		if (s.equals("") || s.equals(null)) {
			System.out.println("�� �� ����� �������� ��������");
			flag = false;
		}
		return flag;
	}

	public static String oneValue(String s) {
		String res = "";
		boolean flag = true;
		for (int i = 0; i < s.length(); i++) {
			switch (s.charAt(i)) {
			
			case '0':
			case '1':
			case '2':
			case '3':
			case '4':
			case '5':
			case '6':
			case '7':
			case '8':
			case '9':{
				if(flag){
				res += s.charAt(i);}
				break;
			}
			default: {
				flag=false;
				break;
			}}
			
		}
		return res;
	}
}
