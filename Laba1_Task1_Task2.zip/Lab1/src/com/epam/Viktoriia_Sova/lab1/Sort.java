package com.epam.Viktoriia_Sova.lab1;

import java.util.Arrays;

public class Sort {
	public static int ARRAY_LENGTH = 10;
	private static int[] a = new int[ARRAY_LENGTH];
	private static int[] arrCopy = { 10, 9, 8, 7, 6, 5, 4, 3, 2, 1 };

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long start = System.nanoTime();
		long finish = System.nanoTime();
		start = finish;
		for (int i = 0; i < ARRAY_LENGTH; i++)
			a[i] = arrCopy[i];
		quickSort();
		System.out.println("�������: " + Arrays.toString(a));
		System.out.println("nanoTime: " + (System.nanoTime() - start));
		System.out.println();
		finish = System.nanoTime();
		
		
		start = finish;
		for (int i = 0; i < ARRAY_LENGTH; i++)
			a[i] = arrCopy[i];
		shellSort(a);
		System.out.println("�����: " +Arrays.toString(a));
		System.out.println("nanoTime: " + (System.nanoTime() - start));
		System.out.println();
		finish = System.nanoTime();
		
		start = finish;
		for (int i = 0; i < ARRAY_LENGTH; i++)
			a[i] = arrCopy[i];
		selectionSort(a);
		System.out.println("�������: " +Arrays.toString(a));
		System.out.println("nanoTime: " + (System.nanoTime() - start));
		System.out.println();
		finish = System.nanoTime();
		
		start = finish;
		for (int i = 0; i < ARRAY_LENGTH; i++)
			a[i] = arrCopy[i];
		insertionSort(a);
		System.out.println("�������: " +Arrays.toString(a));
		System.out.println("nanoTime: " + (System.nanoTime() - start));
		System.out.println();
		finish = System.nanoTime();
		
		start = finish;
		for (int i = 0; i < ARRAY_LENGTH; i++)
			a[i] = arrCopy[i];
		mergeSort(a, 0, a.length);
		System.out.println("��������: " +Arrays.toString(a));
		System.out.println("nanoTime: " + (System.nanoTime() - start));
		System.out.println();
		finish = System.nanoTime();
	}

	public static void quickSort() {
		int startIndex = 0;
		int endIndex = ARRAY_LENGTH - 1;
		doSort(startIndex, endIndex, a);
	}

	private static void doSort(int start, int end, int[] array) {
		if (start >= end)
			return;
		int i = start, j = end;
		int cur = i - (i - j) / 2;
		while (i < j) {
			while (i < cur && (array[i] <= array[cur])) {
				i++;
			}
			while (j > cur && (array[cur] <= array[j])) {
				j = j - 1;
			}
			if (i < j) {
				int temp = array[i];
				array[i] = array[j];
				array[j] = temp;
				if (i == cur)
					cur = j;
				else if (j == cur)
					cur = i;
			}
		}
		doSort(start, cur, array);
		doSort(cur + 1, end, array);
	}

	private static void shellSort(int[] a) {
		int step = a.length / 2;
		while (step > 0) {
			int i, j;
			for (i = step; i < a.length; i++) {
				int value = a[i];
				for (j = i - step; (j >= 0) && (a[j] > value); j -= step)
					a[j + step] = a[j];
				a[j + step] = value;
			}
			step /= 2;
		}

	}

	private static void selectionSort(int[] arr) {
		int min, temp;
		int length = arr.length;
		for (int i = 0; i < length - 1; i++) {
			min = i;
			for (int j = i + 1; j < length; j++) {
				if (arr[j] < arr[min]) {
					min = j;
				}
			}
			if (min != i) {
				temp = arr[i];
				arr[i] = arr[min];
				arr[min] = temp;
			}
		}
	}

	private static void insertionSort(int[] array) {
		for (int i = 1; i < array.length; i++) {
			int cur = array[i];
			int j = i;
			while (j > 0 && cur < array[j - 1]) {
				array[j] = array[j - 1];
				j--;
			}
			array[j] = cur;
		}
	}

	private static void mergeSort(int[] a, int low, int high) {
		if (low + 1 < high) {
			int mid = (low + high) >>> 1;
			mergeSort(a, low, mid);
			mergeSort(a, mid, high);
			int size = high - low;
			int[] b = new int[size];
			int i = low;
			int j = mid;
			for (int k = 0; k < size; k++) {
				if (j >= high || i < mid && a[i] < a[j]) {
					b[k] = a[i++];
				} else {
					b[k] = a[j++];
				}
			}
			System.arraycopy(b, 0, a, low, size);
		}

	}
}
